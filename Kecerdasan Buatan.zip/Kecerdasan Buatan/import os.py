import os
print("Cek isi dataset/train/douglas_fir:", os.listdir("dataset/train/douglas_fir"))
print("Cek isi dataset/train/white_pine:", os.listdir("dataset/train/white_pine"))